<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "cms_db"; // তোমার DB নাম ঠিক রাখো

$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = isset($_POST['sql_query']) ? trim($_POST['sql_query']) : "";

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Query Result - CMS</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #74ebd5, #9face6);
      margin: 0;
      padding: 40px;
      color: #222;
    }

    .result-container {
      background-color: #ffffffde;
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 0 25px rgba(0,0,0,0.15);
      max-width: 900px;
      margin: auto;
      animation: fadeIn 0.8s ease-in-out;
    }

    h2 {
      text-align: center;
      color: #4e00c2;
      text-shadow: 0 0 2px rgba(78, 0, 194, 0.2);
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }

    th {
      background: linear-gradient(90deg, #74ebd5, #9face6);
      color: #222;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    tr:hover {
      background-color: #eef9ff;
      transition: background-color 0.2s;
    }

    .success-msg {
      color: green;
      font-weight: bold;
      text-align: center;
    }

    .error-msg {
      color: red;
      font-weight: bold;
      text-align: center;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .back-btn {
      display: block;
      margin: 30px auto 0;
      text-align: center;
    }

    .back-btn a {
      background-color: #007bff;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      transition: 0.3s ease;
    }

    .back-btn a:hover {
      background-color: #0056b3;
      transform: scale(1.05);
    }

  </style>
</head>
<body>

<div class="result-container">
  <h2>Query Result</h2>

<?php
if (!empty($sql)) {
    // Run the SQL query
    $result = $conn->query($sql);

    if ($result) {
        // If it's a SELECT query
        if ($result instanceof mysqli_result) {
            if ($result->num_rows > 0) {
                echo "<table><tr>";
                while ($field = $result->fetch_field()) {
                    echo "<th>" . htmlspecialchars($field->name) . "</th>";
                }
                echo "</tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    foreach ($row as $value) {
                        echo "<td>" . htmlspecialchars($value) . "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='success-msg'>✅ Query executed, but no rows found.</p>";
            }
        } else {
            echo "<p class='success-msg'>✅ Query executed successfully.</p>";
        }
    } else {
        echo "<p class='error-msg'>❌ Error: " . $conn->error . "</p>";
    }
} else {
    echo "<p class='error-msg'>⚠️ No SQL query provided.</p>";
}
?>

<div class="back-btn">
  <a href="index.html">🔙 Go Back</a>
</div>

</div>

</body>
</html>
